#include <Arduino.h>
#include <esp_now.h>
#include <WiFi.h>
#include <ESP32Servo.h>
#include <SBUS2.h>
#include <FastLED.h>


uint8_t FrameErrorRate = 0;
int16_t channel[18] = {0};
int16_t channelExport[18] = {0};

//


//Pin pour les LED_PIN
#define LED_PIN 32
#define NUM_LEDS 20
CRGB leds[NUM_LEDS];


Servo ESC;

int DZ =20;
int Position = 90; 


//int capteur a effet hall
#define HALL_SENSOR_PIN 33
int Vitesse_end_stop = 200;
int Durer_deroulage = 500;
int lastMillis = 0;

//void MOT_END_STOP(){
 // ESC.write(1500);
  //Serial.println("stop_dessant");
  //delay(Durer_deroulage);
//}
// détection_fin_de_course
void IRAM_ATTR END_STOP(){
  if(lastMillis - millis() < Durer_deroulage){
    ESC.write(1500-Vitesse_end_stop);
  }
  lastMillis = millis();
  
}








// Structure pour les données à envoyer
struct Payload {
  int servoPosition;
};

// Déclaration de la structure pour le largueur
Payload myData;

// Déclaration de l'instance Servo
Servo monServo;

// REPLACE WITH YOUR RECEIVER MAC Address
uint8_t broadcastAddress[] = {0x48, 0xE7, 0x29, 0x8C, 0x7F, 0xDC}; 


esp_now_peer_info_t peerInfo;    //ppelez cette fonction pour coupler un appareil et transmettez en argument l'adresse MAC homologue.

// callback when data is sent
void OnDataSent(const uint8_t *mac_addr, esp_now_send_status_t status) {
  Serial.print("\r\nLast Packet Send Status:\t");
  Serial.println(status == ESP_NOW_SEND_SUCCESS ? "Delivery Success" : "Delivery Fail");
}

//fonction_led

void ClignotementLED(){
 for (int i = 0; i < NUM_LEDS; i++)
 {
  leds[i] = CRGB(255,69,0);
  FastLED.show();
 }
 delay(1000);
  for (int i = 0; i < NUM_LEDS; i++)
 {
  leds[i] = CRGB(0,0,0);
  FastLED.show();
 }
 delay(1000);
}



void LED_FIX(){
 for (int i = 0; i < NUM_LEDS; i++)
 {
  leds[i] = CRGB(255,69,0);
  FastLED.show();
 }
}

//*****************************************************************************
//********************************** SETUP ************************************
//*****************************************************************************


void setup() {

  Serial.begin(115200);           // Init Serial Monitor
  attachInterrupt(HALL_SENSOR_PIN, END_STOP, FALLING);
  WiFi.mode(WIFI_STA);            // Set device as a Wi-Fi Station
  ESC.attach(4, 1000, 2000);      // pin ou est branche l ESC du moteur du treuil

  //LED setup
  FastLED.addLeds<WS2812, LED_PIN, GRB>(leds, NUM_LEDS);
  //FastLED.setBrightness(55);
  FastLED.setMaxPowerInVoltsAndMilliamps(5,500);
  FastLED.clear();
  FastLED.show();

  // ***********  Init ESP-NOW ***********
  if (esp_now_init() != ESP_OK) {
    Serial.println("Error initializing ESP-NOW");
    return;
  }

  // Once ESPNow is successfully Init, we will register for Send CB to
  // get the status of Trasnmitted packet
  esp_now_register_send_cb(OnDataSent);

    // Register peer
  memcpy(peerInfo.peer_addr, broadcastAddress, 6);
  peerInfo.channel = 0;  
  peerInfo.encrypt = false;
  
  // Add peer        
  if (esp_now_add_peer(&peerInfo) != ESP_OK){
    Serial.println("Failed to add peer");
    return;

  }

  // Attachement du servo moteur au pin approprié
  monServo.attach(13);  // pin du servo  
 // ***************** end Init ESP-NOW *****************


 // ***************** Setup SBUS **************
  SBUS2_Setup(16,17);     // For ESP32 set RX and TX Pin Number
 // *****************  end Setup SBUS **************


 // pinMode(HALL_SENSOR_PIN, INPUT);
}





//*****************************************************************************
//********************************** LOOP ************************************
//****************************************************************************

void loop() {
    
    if(SBUS_Ready()){                               // SBUS Disponible
    for(uint8_t i = 0; i<17; i++){
      channel[i] = SBUS2_get_servo_data(i);        // Channel = Servo Value of Channel

        /*Serial.print(">CH");
        Serial.print(i+1);
        Serial.print(":");
        Serial.println(channel[i]);*/

      channelExport[i] = map(channel[i], 173, 1810, 1000, 2000); 
      //if(channelExport[i] < (1000+dz) && channelExport[i] > (1000-dz) )  {    channelExport[i] = 1000;  }
    }
    FrameErrorRate = SBUS_get_FER();
    
  }


  if(channel[0]>0){
   LED_FIX();
  }
  else{
   ClignotementLED();
  }

  



  #if defined (ESP32)
      //delay(10);
      for(uint8_t J = 0; J<17; J++){
        Serial.print(">EXCH");
        Serial.print(J+1);
        Serial.print(":");
        Serial.println(channelExport[J]);
      }
      Serial.print("Error Rate: ");
      Serial.print(FrameErrorRate);
      Serial.println();
  #else
    Serial.print("!defined (ESP32)");
  #endif // ESP32


  if (channelExport[0] >= -DZ && channelExport[0] <= +DZ) {
    channelExport[0] = 0;
  }
 


  ESC.write(channelExport[0]);
  /*Serial.println("");  
  Serial.print("channelExport ESC= ");
  Serial.println(channelExport[0]);*/


  monServo.write(channelExport[1]);
  /*Serial.println("");  
  Serial.print("channelExport Servo largage = ");
  Serial.println(channelExport[1]);*/
  
  if (channelExport[1] >= 1500) 
  {
    Position = 90; 
  }
  else 
  { 
    Position = 135;
  }

// Mettez à jour la position du servo moteur
  myData.servoPosition = Position;

  
  // Send message via ESP-NOW
  esp_err_t result = esp_now_send(broadcastAddress, (uint8_t *) &myData, sizeof(myData));
   
  if (result == ESP_OK) {
    Serial.println("Sent with success");
  }
  else {
    Serial.println("Error sending the data");
  }
  //delay(1000);



  //******** CAPTEUR A EFFET HALL *********

  /*int hallValue = analogRead(HALL_SENSOR_PIN);
    Serial.print("Valeur du capteur : ");
    Serial.println(hallValue);
   //delay(500); // Attendre 0.5 seconde avant de lire à nouveau
*/

}













